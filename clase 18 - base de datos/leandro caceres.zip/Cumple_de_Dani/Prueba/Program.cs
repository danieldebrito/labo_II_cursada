﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Conexion;

namespace Prueba
{
    class Program
    {
        static void Main(string[] args)
        {
            //PARTE 1 MOSTRAR CON STRING
            ConexionSQL c = new ConexionSQL();
            if (c.TestConetion())
            {
                Console.WriteLine("Conexion ok");
                Console.WriteLine(c.TraerInfo());
            }
            else
                Console.WriteLine("No ok");

            Console.ReadKey();

            //PARTE 2 CARGAR LISTA
            List<Persona> pers = new List<Persona>();
            c.TraerInfo(pers);
            foreach (Persona p in pers)
                Console.WriteLine(p.ToString());
            Console.ReadKey();

            //PARTE 3 AGREGAR PERSONA A TABLA
            Persona persona = new Persona(0,"Juan", "Cruz", 2);
            if (c.AgregarPersona(persona))
                Console.WriteLine("Agregado OK");
            Console.WriteLine(c.TraerInfo());
            Console.ReadKey();

            //PARTE 4 MODIFICAR DATOS
            pers.Clear();
            c.TraerInfo(pers);
            pers[2].Apellido = "Caceres";
            pers[2].Nombre = "Leandro";

            if (c.ModificarPersona(pers[2]))
                Console.WriteLine("Modificado ok");
            Console.WriteLine(c.TraerInfo());
            Console.ReadKey();

            //PARTE 5 ELIMINAR DATO DE TABLA
            pers.Clear();
            c.TraerInfo(pers);
            if(c.EliminarPersona(pers[2]))
                Console.WriteLine("Eliminado ok");
            Console.WriteLine(c.TraerInfo());
            Console.ReadKey();
        }


    }
}
