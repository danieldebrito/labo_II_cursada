﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Conexion
{
    public class Persona
    {
        public int _id;
        public string _nombre;
        public string _apellido;
        public int _edad;

        public int ID { get { return this._id; } }
        public string Nombre { get { return this._nombre; } set { this._nombre = value; } }
        public string Apellido { get { return this._apellido; } set { this._apellido = value; } }
        public int Edad { get { return this._edad; } set { this._edad = value; } }

        public Persona(int id, string nombre, string apellido, int edad)
        {
            this._apellido = apellido;
            this._edad = edad;
            this._id = id;
            this._nombre = nombre;
        }

        public override string ToString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("ID: " + this._id);
            sb.Append(" Nombre: " + this._nombre);
            sb.Append(" Apellido: " + this._apellido);
            sb.Append(" Edad: " + this._edad);
            return sb.ToString();
        }
    }
}
