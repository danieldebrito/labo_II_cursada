﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Conexion
{
    public class ConexionSQL
    {
        private SqlConnection _conexion;
        private SqlCommand _comando;

        public ConexionSQL()
        {
            this._conexion = new SqlConnection(Properties.Settings.Default.Cadena_Padron_Personas);
            this._comando = new SqlCommand();
        }

        public bool TestConetion()
        {
            try
            {
                this._conexion.Open();
                this._conexion.Close();
                return true;
            }
            catch (Exception e)
            {
                return false;
            }
        }

        public string TraerInfo()
        {
            StringBuilder sb = new StringBuilder();
            this._conexion.Open();
            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = "SELECT *  FROM Personas ORDER BY nombre, apellido";

            SqlDataReader reader = this._comando.ExecuteReader();
            while(reader.Read())
            {
                sb.AppendLine(reader["id"].ToString() + " " + reader["nombre"].ToString() + " " + reader["apellido"].ToString() + reader["edad"].ToString());
            }
            this._conexion.Close();
            return sb.ToString();
        }

        public void TraerInfo(List<Persona> p)
        {
            this._conexion.Open();
            this._comando.Connection = this._conexion;
            this._comando.CommandType = CommandType.Text;
            this._comando.CommandText = "SELECT *  FROM Personas ORDER BY nombre, apellido";


            SqlDataReader r = this._comando.ExecuteReader();
            while (r.Read())
            {
                p.Add(new Persona(int.Parse(r["id"].ToString()),r[1].ToString(),r[2].ToString(),int.Parse(r[3].ToString())));
            }
            this._conexion.Close();
        }

        public bool AgregarPersona(Persona p)
        {
            bool resultado = false;
            try
            {
                this._conexion.Open();
                this._comando.Connection = this._conexion;
                this._comando.CommandType = CommandType.Text;
                this._comando.CommandText = "INSERT INTO Personas (nombre,apellido,edad) VALUES('" + p.Nombre + "','" + p.Apellido + "'," + p.Edad + ")";
                if (this._comando.ExecuteNonQuery() > 0)
                    resultado = true;
                this._conexion.Close();
                return resultado;
            }
            catch (Exception e)
            {
                this._conexion.Close();
                return resultado;
            }
        }

        public bool ModificarPersona(Persona p)
        {
            bool resultado = false;
            try
            {
                this._conexion.Open();
                this._comando.Connection = this._conexion;
                this._comando.CommandType = CommandType.Text;
                this._comando.CommandText = "UPDATE Personas SET nombre = '" + p.Nombre + "', apellido = '" + p.Apellido + "', edad = " + p.Edad + " WHERE id = "+p._id;
                if (this._comando.ExecuteNonQuery() > 0)
                    resultado = true;
                this._conexion.Close();
                return resultado;
            }
            catch (Exception e)
            {
                this._conexion.Close();
                return resultado;
            }
        }

        public bool EliminarPersona(Persona p)
        {
            bool resultado = false;
            try
            {
                this._conexion.Open();
                this._comando.Connection = this._conexion;
                this._comando.CommandType = CommandType.Text;
                this._comando.CommandText = "DELETE FROM Personas WHERE id = " + p._id;
                if (this._comando.ExecuteNonQuery() > 0)
                    resultado = true;
                this._conexion.Close();
                return resultado;
            }
            catch (Exception e)
            {
                this._conexion.Close();
                return resultado;
            }
        }
    }
}
